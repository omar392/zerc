<?php $__env->startSection('content'); ?>
    <!-- Banner -->
    <div class="banner-area">
        <div class="banner-shape">
            <img src="<?php echo e(asset('frontend/assets/img/home-one/banner/shape-bottom.png')); ?>" alt="Shape">
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-8">
                    <div class="banner-content">
                        <div class="d-table">
                            <div class="d-table-cell">
                                <h1><?php echo e($setting->title); ?></h1>
                                <p><?php echo e($setting->description); ?></p>

                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="banner-img">
                        <img src="<?php echo e(asset('dashboard/' . $cover->image_about)); ?>" alt="Shape">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Banner -->

    <!-- about -->
    <section class="work-area pb-70">
        <div class="container">
            <div class="section-title">
                
                <h2><?php echo e(__('site.about')); ?></h2>
            </div>
            <div class="row">
                <div class="col-sm-6 col-lg-4">
                    <div class="work-item">
                        <i class="flaticon-verify"></i>
                        <span><?php echo e(__('site.about')); ?></span>
                        <p><?php echo $about->about; ?></p>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="work-item">
                        <i class="flaticon-comment"></i>
                        <span><?php echo e(__('site.mission')); ?></span>
                        <p><?php echo $about->mission; ?></p>
                    </div>
                </div>
                <div class="col-sm-6 offset-sm-3 offset-lg-0 col-lg-4">
                    <div class="work-item">
                        <i class="flaticon-file"></i>
                        <span><?php echo e(__('site.vision')); ?></span>
                        <p><?php echo $about->vision; ?></p>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- End about -->

    <!-- services -->
    <section class="location-area pb-70">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <div class="section-title">
                        <h2><?php echo e(__('site.services')); ?></h2>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="cmn-link">
                        <a href="<?php echo e(route('front.services')); ?>">
                            <i class="flaticon-right-arrow one"></i>
                            <?php echo e(__('site.read')); ?>

                            <i class="flaticon-right-arrow two"></i>
                        </a>
                    </div>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="location-slider owl-theme owl-carousel">
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="location-item">
                        <div class="top">
                            <a href="<?php echo e(route('front.services.details', [str_replace(' ', '-', $item->url)])); ?>">
                                <img src="<?php echo e(asset('dashboard/services/' . $item->image)); ?>" alt="<?php echo e($item->title); ?>">
                            </a>
                        </div>
                        <h3>
                            <a
                                href="<?php echo e(route('front.services.details', [str_replace(' ', '-', $item->url)])); ?>"><?php echo e($item->title); ?></a>
                        </h3>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!-- End services -->

    <!-- jobs -->
    <section class="blog-area pb-70">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <div class="section-title">
                        <h2><?php echo e(__('site.jobs')); ?></h2>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="cmn-link">
                        <a href="<?php echo e(route('front.news')); ?>">
                            <i class="flaticon-right-arrow one"></i>
                            <?php echo e(__('site.read')); ?>

                            <i class="flaticon-right-arrow two"></i>
                        </a>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-sm-6 col-lg-4">
                    <div class="blog-item">
                        <div class="top">
                            <a href="<?php echo e(route('front.job.details', [str_replace(' ', '-', $item->url)])); ?>">
                                <img src="<?php echo e(asset('dashboard/employments/' . $item->image)); ?>" alt="Blog">
                            </a>
                        </div>
                        <span><?php echo e($item->created_at->format('d F Y')); ?></span>
                        <h3>
                            <a href="<?php echo e(route('front.job.details', [str_replace(' ', '-', $item->url)])); ?>"><?php echo e($item->title); ?></a>
                        </h3>
                        <div class="cmn-link">
                            <a href="<?php echo e(route('front.job.details', [str_replace(' ', '-', $item->url)])); ?>">
                                <i class="flaticon-right-arrow one"></i>
                                <?php echo e(__('site.more')); ?>

                                <i class="flaticon-right-arrow two"></i>
                            </a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>
    <!-- End jobs -->

        <!-- Counter -->
    <div class="counter-area pt-100">
        <div class="counter-shape">
            <img src="<?php echo e(asset('frontend/assets/img/home-one/banner/shape-bottom.png')); ?>" alt="Shape">
        </div>
        <div class="container">
            <div class="row">
                <div class="col-sm-6 col-lg-4">
                    <div class="counter-item">
                        <i class="flaticon-candidate"></i>
                        <p><?php echo e(__('site.input0')); ?></p>
                        <h3>
                            <span class="odometer"  dir="ltr"  data-count="<?php echo e($counter->input0); ?>"><?php echo e($counter->input0); ?></span>
                        </h3>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="counter-item">
                        <i class="flaticon-working-at-home"></i>
                        <p><?php echo e(__('site.input3')); ?></p>
                        <h3>
                            <span class="odometer"  dir="ltr"  data-count="<?php echo e($counter->input3); ?>"><?php echo e($counter->input3); ?></span>
                        </h3>
                    </div>
                </div>
                <div class="col-sm-6 col-lg-4">
                    <div class="counter-item">
                        <i class="flaticon-choice"></i>
                        <p><?php echo e(__('site.jobs')); ?></p>
                        <h3>
                            <span class="odometer"  dir="ltr"  data-count="<?php echo e($counter->input2); ?>"><?php echo e($counter->input2); ?></span>
                        </h3>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Counter -->


    <!-- Partner -->
    <div class="partner-area pt-100 pb-70">
        <div class="container">
            <div class="partner-slider owl-theme owl-carousel">
                <?php $__currentLoopData = $partners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="partner-item">
                    <img src="<?php echo e(asset('dashboard/partners/' . $item->image)); ?>" style="width: 220px;height: 100px;" alt="Partner">
                    <img src="<?php echo e(asset('dashboard/partners/' . $item->image)); ?>" style="width: 220px;height: 100px;" alt="Partner">
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    <!-- End Partner -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\dell\Desktop\zirikyashi\resources\views/frontend/home.blade.php ENDPATH**/ ?>