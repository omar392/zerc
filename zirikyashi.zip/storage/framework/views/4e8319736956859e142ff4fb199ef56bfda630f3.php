        <!-- Preloader -->
        <div class="loader">
            <div class="d-table">
                <div class="d-table-cell">
                    <div class="spinner"></div>
                </div>
            </div>
        </div>
        <!-- End Preloader -->

        <!-- Navbar -->
        <div class="navbar-area fixed-top">
            <!-- Menu For Mobile Device -->
            <div class="mobile-nav">
                <a href="<?php echo e(route('front.home')); ?>" class="logo">
                    <img src="<?php echo e(asset('dashboard/' . $setting->image)); ?>" alt="Logo">
                </a>
            </div>

            <!-- Menu For Desktop Device -->
            <div class="main-nav">
                <div class="container-fluid">
                    <nav class="navbar navbar-expand-md navbar-light">
                        <a class="navbar-brand" href="<?php echo e(route('front.home')); ?>">
                            <img src="<?php echo e(asset('dashboard/' . $setting->image)); ?>" class="logo-one" alt="Logo">
                            <img src="<?php echo e(asset('dashboard/' . $setting->image)); ?>" class="logo-two" alt="Logo">
                        </a>
                        <div class="collapse navbar-collapse mean-menu" id="navbarSupportedContent">
                            <ul class="navbar-nav">
                                <li class="nav-item">
                                    <a href="<?php echo e(route('front.home')); ?>"
                                        class="nav-link dropdown-toggle <?php echo e(URL::route('front.home') === URL::current() ? 'active' : ''); ?>"><?php echo e(__('site.home')); ?></i></a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('front.about')); ?>"
                                        class="nav-link dropdown-toggle <?php echo e(URL::route('front.about') === URL::current() ? 'active' : ''); ?>"><?php echo e(__('site.about')); ?></a>
                                </li>
                                <li class="nav-item">
                                    <a href="<?php echo e(route('front.services')); ?>"
                                        class="nav-link dropdown-toggle <?php echo e(URL::route('front.services') === URL::current() ? 'active' : ''); ?>"><?php echo e(__('site.services')); ?>

                                        <i class='bx bx-chevron-down'></i></a>
                                    <ul class="dropdown-menu">
                                        <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="nav-item">
                                                <a href="<?php echo e(route('front.services.details', [str_replace(' ', '-', $item->url)])); ?>"
                                                    class="nav-link"><?php echo e($item->title); ?></a>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </ul>
                                </li>
                                <li class="nav-item">
                                    <a href="#"
                                        class="nav-link dropdown-toggle <?php echo e(URL::route('front.gallery') === URL::current() ? 'active' : ''); ?> <?php echo e(URL::route('front.news') === URL::current() ? 'active' : ''); ?> <?php echo e(URL::route('front.faqs') === URL::current() ? 'active' : ''); ?> <?php echo e(URL::route('front.blog') === URL::current() ? 'active' : ''); ?>"><?php echo e(__('site.pages')); ?>

                                        <i class='bx bx-chevron-down'></i></a>
                                    <ul class="dropdown-menu">
                                        <li class="nav-item">
                                            <a href="<?php echo e(route('front.blog')); ?>"
                                                class="nav-link <?php echo e(URL::route('front.blog') === URL::current() ? 'active' : ''); ?>"><?php echo e(__('site.blog')); ?></a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="<?php echo e(route('front.faqs')); ?>"
                                                class="nav-link <?php echo e(URL::route('front.faqs') === URL::current() ? 'active' : ''); ?>"><?php echo e(__('site.faqs')); ?></a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="<?php echo e(route('front.news')); ?>"
                                                class="nav-link <?php echo e(URL::route('front.news') === URL::current() ? 'active' : ''); ?>"><?php echo e(__('site.news')); ?></a>
                                        </li>
                                        <li class="nav-item">
                                            <a href="<?php echo e(route('front.gallery')); ?>"
                                                class="nav-link <?php echo e(URL::route('front.gallery') === URL::current() ? 'active' : ''); ?>"><?php echo e(__('site.gallery')); ?></a>
                                        </li>
                                    </ul>
                                </li>

                                <li class="nav-item">
                                    <a href="<?php echo e(route('front.contact')); ?>"
                                        class="nav-link <?php echo e(URL::route('front.contact') === URL::current() ? 'active' : ''); ?>"><?php echo e(__('site.contact')); ?></a>
                                </li>

                                <li class="nav-item">
                                    <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($localeCode == LaravelLocalization::getCurrentLocale()): ?>
                                        <?php elseif($url = LaravelLocalization::getLocalizedURL($localeCode)): ?>
                                            <a href="<?php echo e(LaravelLocalization::getLocalizedURL($localeCode, null, [], true)); ?>"
                                                class="flag-bar">
                                                <?php if(app()->getLocale() == 'ar'): ?>
                                                    <span><b>English</b></span>
                                                <?php else: ?>
                                                    <span><b>العربية</b></span>
                                                <?php endif; ?>
                                            </a>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </li>

                            </ul>
                            <div class="side-nav">

                                <a class="cmn-btn" href="<?php echo e(route('front.employmment')); ?>">
                                    <?php echo e(__('site.emp')); ?>

                                    <i class='bx bx-user'></i>
                                </a>
                                <a class="cmn-btn" href="<?php echo e(route('front.jobs')); ?>">
                                    <?php echo e(__('site.jobs')); ?>

                                    <i class='bx bx-plus'></i>
                                </a>
                            </div>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
        <!-- End Navbar -->
<?php /**PATH C:\Users\dell\Desktop\zirikyashi\resources\views/frontend/layouts/header.blade.php ENDPATH**/ ?>