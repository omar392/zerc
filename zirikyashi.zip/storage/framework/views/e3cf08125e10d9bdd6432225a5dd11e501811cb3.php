        <!-- Footer -->
        <footer class="pt-100 pb-70">
            <div class="container">
                <div class="row">
                    <div class="col-sm-6 col-lg-4">
                        <div class="footer-item">
                            <div class="footer-logo">
                                <a class="logo" href="<?php echo e(route('front.home')); ?>">
                                    <img src="<?php echo e(asset('dashboard/' . $setting->image)); ?>" class="logo-one"
                                        alt="Logo">
                                    <img src="<?php echo e(asset('dashboard/' . $setting->image)); ?>" class="logo-two"
                                        alt="Logo">
                                </a>
                                <ul>
                                    <li>
                                        <span><?php echo e(__('site.address')); ?>: </span>
                                        <?php echo e($setting->address); ?>

                                    </li>
                                    <li>
                                        <span><?php echo e(__('site.email')); ?>: </span>
                                        <a href="mailto:<?php echo e($setting->email); ?>"><?php echo e($setting->email); ?></a>
                                    </li>
                                    <li>
                                        <span><?php echo e(__('site.phone')); ?>: </span>
                                        <a href="tel:<?php echo e($setting->phone); ?>"><?php echo e($setting->phone); ?></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-3">
                        <div class="footer-item">
                            <div class="footer-service">
                                <h3><?php echo e(__('site.services')); ?></h3>
                                <ul>
                                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li>
                                            <a
                                                href="<?php echo e(route('front.services.details', [str_replace(' ', '-', $item->url)])); ?>"><?php echo e($item->title); ?></a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-2">
                        <div class="footer-item">
                            <div class="footer-service">
                                <h3><?php echo e(__('site.pages')); ?></h3>
                                <ul>
                                    <li>
                                        <a href="<?php echo e(route('front.about')); ?>"><?php echo e(__('site.about')); ?></a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('front.employmment')); ?>"
                                            target="_blank"><?php echo e(__('site.emp')); ?></a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('front.jobs')); ?>"><?php echo e(__('site.jobs')); ?></a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('front.gallery')); ?>"><?php echo e(__('site.gallery')); ?></a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('front.blog')); ?>"><?php echo e(__('site.blog')); ?></a>
                                    </li>
                                    <li>
                                        <a href="<?php echo e(route('front.contact')); ?>"><?php echo e(__('site.contact')); ?></a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                    <div class="col-sm-6 col-lg-3">
                        <div class="footer-item">
                            <div class="footer-newsletter">
                                <h3><?php echo e(__('site.newsletter')); ?></h3>
                                <p><?php echo e(__('site.sub')); ?></p>
                                <form id="emailservice" action="<?php echo e(route('email.email')); ?>" method="POST"
                                    novalidate="novalidate">
                                    <?php echo csrf_field(); ?>
                                    <input type="text" name="email" id="email"
                                        placeholder="<?php echo e(__('site.email')); ?>" class="form-control">
                                    <span class="text-danger error-text email_err"></span>
                                    <button class="btn btn-submittt" type="submit">
                                        <i class="flaticon-send"></i>
                                    </button>

                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!-- End Footer -->

        <!-- Copyright -->
        <div class="copyright-area">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-6">
                        <div class="copyright-item">
                            <ul>
                                <li>
                                    <a href="<?php echo e($setting->facebook); ?>" target="_blank">
                                        <i class='bx bxl-snapchat'></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e($setting->twitter); ?>" target="_blank">
                                        <i class='bx bxl-twitter'></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e($setting->linkedin); ?>" target="_blank">
                                        <i class='bx bxl-linkedin-square'></i>
                                    </a>
                                </li>
                                <li>
                                    <a href="<?php echo e($setting->instagram); ?>" target="_blank">
                                        <i class='bx bxl-instagram'></i>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="copyright-item">
                            <p><?php echo e($setting->footer); ?> <?php echo e(now()->year); ?> ،، <?php echo e(__('site.designed')); ?> <a href="<?php echo e(route('front.home')); ?>"
                                    target="_blank"> Joud Tech </a></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Copyright -->
<?php /**PATH C:\Users\dell\Desktop\zirikyashi\resources\views/frontend/layouts/footer.blade.php ENDPATH**/ ?>