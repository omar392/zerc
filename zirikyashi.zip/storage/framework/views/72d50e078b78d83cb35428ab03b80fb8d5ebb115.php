<?php $__env->startSection('content'); ?>


        <!-- Error -->
        <div class="error-area">
            <div class="d-table">
                <div class="d-table-cell">
                    <div class="container">
                        <div class="error-content">
                            <h1>404</h1>
                            <h2><?php echo e(__('site.404')); ?></h2>
                            <p><?php echo e(__('site.not')); ?></p>
                            <a href="<?php echo e(route('front.home')); ?>"><?php echo e(__('site.home')); ?></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Error -->


<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\dell\Desktop\zirikyashi\resources\views/errors/404.blade.php ENDPATH**/ ?>