<?php $__env->startSection('title', __('site.contact-')); ?>
<?php $__env->startSection('content'); ?>
    <!-- Page Title -->
    <div class="page-title-area" style="background-image: url('<?php echo e(asset('dashboard/' . $cover->image_contact)); ?>')">
        <div class="d-table">
            <div class="d-table-cell">
                <div class="container">
                    <div class="title-item">
                        <h2><?php echo e(__('site.contact')); ?></h2>
                        <ul>
                            <li>
                                <img src="<?php echo e(asset('frontend/assets/img/30-30.png')); ?>" alt="Image">
                                <a href="<?php echo e(route('front.home')); ?>"><?php echo e(__('site.home')); ?></a>
                            </li>
                            <li>
                                <span>/</span>
                            </li>
                            <li>
                                <?php echo e(__('site.contact')); ?>

                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Page Title -->

    <!-- Info -->
    <div class="contact-info-area pt-100 pb-70">
        <div class="container">
            <div class="row">
                <div class="col-sm-6 col-lg-12">
                    <div class="info-item">
                        <i class='bx bx-world'></i>
                        <h3><?php echo e($setting->name); ?></h3>
                        <p><?php echo $setting->address; ?></p>
                        <ul>
                            <li>
                                <span><?php echo e(__('site.phone')); ?>:</span> <a
                                    href="tel:<?php echo e($setting->phone); ?>"><?php echo e($setting->phone); ?></a>
                            </li>
                            <li>
                                <span><?php echo e(__('site.email')); ?>:</span> <a
                                    href="mailto:<?php echo e($setting->email); ?>"><?php echo e($setting->email); ?></a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- End Info -->

    <!-- Contact -->
    <div class="contact-form-area pb-100">
        <div class="container">
            <div class="form-item">
                <h2><?php echo e(__('site.contact')); ?></h2>
                <form id="contactInfo" action="<?php echo e(route('contact.save')); ?>" method="POST" novalidate="novalidate">
                    <?php echo csrf_field(); ?>
                    <div class="row">
                        <div class="col-sm-6 col-lg-6">
                            <div class="form-group">
                                <label><?php echo e(__('site.name')); ?></label>
                                <input type="text" name="name" id="name" placeholder="<?php echo e(__('site.name')); ?>"
                                    class="form-control">
                                <span class="text-danger error-text name_err"></span>
                            </div>
                        </div>

                        <div class="col-sm-6 col-lg-6">
                            <div class="form-group">
                                <label><?php echo e(__('site.email')); ?></label>
                                <input type="text" name="email" id="email" placeholder="<?php echo e(__('site.email')); ?>"
                                    class="form-control">
                                <span class="text-danger error-text email_err"></span>
                            </div>
                        </div>

                        <div class="col-sm-6 col-lg-6">
                            <div class="form-group">
                                <label><?php echo e(__('site.phone')); ?></label>
                                <input type="text" name="phone" id="phone" placeholder="<?php echo e(__('site.phone')); ?>"
                                    class="form-control">
                                <span class="text-danger error-text phone_err"></span>
                            </div>
                        </div>

                        <div class="col-sm-6 col-lg-6">
                            <div class="form-group">
                                <label><?php echo e(__('site.subject')); ?></label>
                                <input type="text" name="subject" id="subject" placeholder="<?php echo e(__('site.subject')); ?>"
                                    class="form-control">
                                <span class="text-danger error-text subject_err"></span>
                            </div>
                        </div>

                        <div class="col-md-12 col-lg-12">
                            <div class="form-group">
                                <label><?php echo e(__('site.message')); ?></label>
                                <textarea name="message" class="form-control" id="message" placeholder="<?php echo e(__('site.message')); ?>" cols="30"
                                    rows="8"></textarea>
                                <span class="text-danger error-text message_err"></span>
                            </div>
                        </div>
                        <div class="col-sm-6 col-lg-6">
                            <div class="form-group">
                                <?php echo NoCaptcha::renderJs(); ?>

                                <?php echo NoCaptcha::display(); ?>

                                <span class="text-danger error-text g-recaptcha-response_err"></span>
                            </div>
                        </div>

                        <div class="col-md-12 col-lg-12">
                            <button type="submit" class="btn btn-submit">
                                <?php echo e(__('site.send')); ?>

                            </button>
                            <div id="msgSubmit" class="h3 text-center hidden"></div>
                            <div class="clearfix"></div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <!-- End Contact -->

    <!-- Map -->
    <div class="map-area">
        <div class="container-fluid p-0">
            <iframe id="map"
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d59843174.53779285!2d62.17507173408571!3d23.728204508550363!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3663f18a24cbe857%3A0xa9416bfcd3a0f459!2sAsia!5e0!3m2!1sen!2sbd!4v1599227927146!5m2!1sen!2sbd"
                allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
        </div>
    </div>
    <!-- End Map -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\dell\Desktop\zirikyashi\resources\views/frontend/contact/index.blade.php ENDPATH**/ ?>