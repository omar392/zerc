<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0, minimal-ui">
    <title><?php echo e(__('admin.adminlogin')); ?></title>
    <meta content="Responsive admin theme build on top of Bootstrap 4" name="description" />
    <meta content="Themesdesign" name="author" />
    <link rel="shortcut icon" href="<?php echo e(asset('dashboard/assets_en/images/favicon.ico')); ?>">
    <?php if(app()->getLocale() == 'en'): ?>
    <link href="<?php echo e(asset('dashboard/assets_en/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('dashboard/assets_en/css/metismenu.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('dashboard/assets_en/css/icons.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('dashboard/assets_en/css/style.css')); ?>" rel="stylesheet" type="text/css">
    <?php endif; ?>
    <?php if(app()->getLocale() == 'ar'): ?>
    <link href="<?php echo e(asset('dashboard/assets_ar/css/bootstrap.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('dashboard/assets_ar/css/metismenu.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('dashboard/assets_ar/css/icons.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('dashboard/assets_ar/css/style.css')); ?>" rel="stylesheet" type="text/css">
    <?php endif; ?>
    <?php echo toastr_css(); ?>
</head>
<body>
    <!-- Begin page -->
    <div class="accountbg"></div>
    <div class="home-btn d-none d-sm-block">
        <?php $__currentLoopData = LaravelLocalization::getSupportedLocales(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $localeCode => $properties): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($localeCode == LaravelLocalization::getCurrentLocale()): ?>
        <?php elseif($url = LaravelLocalization::getLocalizedURL($localeCode)): ?>
        <a href="<?php echo e(LaravelLocalization::getLocalizedURL($localeCode, null, [], true)); ?>" class="text-white"><i class="fas fa-globe h5"></i>
            <?php if(app()->getLocale() == 'ar'): ?>
            <span style="color: #fff;font-family: Tajawal;">English</span>
        <?php else: ?>
            <span style="color: #fff;font-family: Tajawal;">العربية</span>
        <?php endif; ?>
    </a>
        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <div class="wrapper-page">
        <div class="card card-pages shadow-none">
            <div class="card-body">
                <div class="text-center m-t-0 m-b-15">
                    <h1><?php echo e(__('admin.dashboard')); ?></h1>
                </div>
                <h5 class="font-18 text-center"><?php echo e(__('admin.signin')); ?></h5>
                <form class="form-horizontal m-t-30" method="POST" action="<?php echo e(route('login.admin')); ?>">
                    <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <div class="col-12">
                            <label><?php echo e(__('admin.email')); ?> : </label>
                            <input class="form-control" type="email" value="<?php echo e(old('email')); ?>" name="email"  placeholder="<?php echo e(__('admin.email')); ?>">
                            <?php if($errors->has('email')): ?>
                            <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-12">

                            <label><?php echo e(__('admin.password')); ?> : </label>
                            <input class="form-control input-psswd" id="psswd" psswd-shown="false" type="password" name="password" value="<?php echo e(old('password')); ?>" placeholder="<?php echo e(__('admin.password')); ?>">
                            <br>
                            <button type="button" class="button-psswd btn btn-danger sm fa fa-eye"></button>
                            <?php if($errors->has('password')): ?>
                            <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="form-group text-center m-t-20">
                        <div class="col-12">
                            <button class="btn btn-primary btn-block btn-lg waves-effect waves-light" type="submit"><?php echo e(__('admin.login')); ?></button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
         <span class="d-none d-sm-inline-block" style="color: #fff"><?php echo e(now()->year); ?> - Crafted with <i class="mdi mdi-heart text-danger"></i> by Green Way</span>.
    </div>
    <!-- END wrapper -->
    <?php echo jquery(); ?>
    <?php echo toastr_js(); ?>
    <?php echo app('toastr')->render(); ?>
    <script>
        $(document).ready(function() {

    $('.button-psswd').on('click', function() {

        if ($('.input-psswd').attr('psswd-shown') == 'false') {

            $('.input-psswd').removeAttr('type');
            $('.input-psswd').attr('type', 'text');
            $('.input-psswd').removeAttr('psswd-shown');
            $('.input-psswd').attr('psswd-shown', 'true');
        }else {
            $('.input-psswd').removeAttr('type');
            $('.input-psswd').attr('type', 'password');
            $('.input-psswd').removeAttr('psswd-shown');
            $('.input-psswd').attr('psswd-shown', 'false');
        }

    });

});
    </script>
    <!-- jQuery  -->
    <script src="<?php echo e(asset('dashboard/assets_ar/js/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/assets_ar/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/assets_ar/js/metismenu.min.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/assets_ar/js/jquery.slimscroll.js')); ?>"></script>
    <script src="<?php echo e(asset('dashboard/assets_ar/js/waves.min.js')); ?>"></script>
    <!-- App js -->
</body>
</html>
<?php /**PATH C:\Users\dell\Desktop\zirikyashi\resources\views/admin/login.blade.php ENDPATH**/ ?>