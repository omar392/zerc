        <!-- ========== Left Sidebar Start ========== -->
        <div class="left side-menu">
            <div class="slimscroll-menu" id="remove-scroll">

                <!--- Sidemenu -->
                <div id="sidebar-menu">
                    <!-- Left Menu Start -->
                    <ul class="metismenu" id="side-menu">

                        <li class="menu-title"><?php echo e(__('admin.menu')); ?></li>
                        <li>
                            <a href="<?php echo e(route('adminhome')); ?>" class="waves-effect">
                                <i class="icon-accelerator"></i><span class="badge badge-success badge-pill float-right"></span> <span> <?php echo e(__('admin.dashboard')); ?> </span>
                            </a>
                        </li>
                        <?php if(Auth::guard('admin')->user()->hasPermission('roles-read')): ?>
                        <li>
                            <a href="<?php echo e(route('roles.index')); ?>" class="waves-effect">
                                <i class="fas fa-user-lock"></i><span><?php echo e(__('admin.roles')); ?></span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if(Auth::guard('admin')->user()->hasPermission('admins-read')): ?>
                        <li>
                            <a href="<?php echo e(route('admins.index')); ?>" class="waves-effect">
                                <i class="fas fa-user-tag"></i><span><?php echo e(__('admin.administrators')); ?></span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if(Auth::guard('admin')->user()->hasPermission('users-read')): ?>
                        <li>
                            <a href="<?php echo e(route('users.index')); ?>" class="waves-effect">
                                <i class="fas fa-users"></i><span><?php echo e(__('admin.users')); ?></span>
                            </a>
                        </li>
                        <?php endif; ?>
                        
                        <?php if(Auth::guard('admin')->user()->hasPermission('services-read')): ?>
                        <li>
                            <a href="<?php echo e(route('services.index')); ?>" class="waves-effect">
                                <i class="fas fa-image"></i><span class="badge badge-success badge-pill float-right"></span> <span> <?php echo e(__('admin.services')); ?> </span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if(Auth::guard('admin')->user()->hasPermission('news-read')): ?>
                        <li>
                            <a href="<?php echo e(route('news.index')); ?>" class="waves-effect">
                                <i class="fas fa-newspaper"></i><span class="badge badge-success badge-pill float-right"></span> <span> <?php echo e(__('admin.news')); ?> </span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if(Auth::guard('admin')->user()->hasPermission('employments-read')): ?>
                        <li>
                            <a href="<?php echo e(route('employments.index')); ?>" class="waves-effect">
                                <i class="fas fa-briefcase"></i><span class="badge badge-success badge-pill float-right"></span> <span> <?php echo e(__('admin.employments')); ?> </span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if(Auth::guard('admin')->user()->hasPermission('partners-read')): ?>
                        <li>
                            <a href="<?php echo e(route('partners.index')); ?>" class="waves-effect">
                                <i class="fas fa-handshake"></i><span class="badge badge-success badge-pill float-right"></span> <span> <?php echo e(__('admin.partners')); ?> </span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if(Auth::guard('admin')->user()->hasPermission('blogs-read')): ?>
                        <li>
                            <a href="<?php echo e(route('blog.index')); ?>" class="waves-effect">
                                <i class="fas fa-edit"></i><span class="badge badge-success badge-pill float-right"></span> <span> <?php echo e(__('admin.blogs')); ?> </span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if(Auth::guard('admin')->user()->hasPermission('faqs-read')): ?>
                        <li>
                            <a href="<?php echo e(route('faqs.index')); ?>" class="waves-effect">
                                <i class="fas fa-question"></i><span class="badge badge-success badge-pill float-right"></span> <span> <?php echo e(__('admin.faqs')); ?> </span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if(Auth::guard('admin')->user()->hasPermission('countries-read')): ?>
                        <li>
                            <a href="<?php echo e(route('countries.index')); ?>" class="waves-effect">
                                <i class="fas fa-flag"></i><span class="badge badge-success badge-pill float-right"></span> <span> <?php echo e(__('admin.countries')); ?> </span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if(Auth::guard('admin')->user()->hasPermission('galleries-read')): ?>
                        <li>
                            <a href="<?php echo e(route('gallery.index')); ?>" class="waves-effect">
                                <i class="fas fa-camera"></i><span class="badge badge-success badge-pill float-right"></span> <span> <?php echo e(__('admin.gallery')); ?> </span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if(Auth::guard('admin')->user()->hasPermission('abouts-read')): ?>
                        <li>
                            <a href="<?php echo e(route('abouts.index')); ?>" class="waves-effect">
                                <i class="fas fa-book-open"></i><span><?php echo e(__('admin.abouts')); ?></span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if(Auth::guard('admin')->user()->hasPermission('seos-read')): ?>
                        <li>
                            <a href="<?php echo e(route('seo.index')); ?>" class="waves-effect">
                                <i class="fas fa-search"></i><span><?php echo e(__('admin.seos')); ?></span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if(Auth::guard('admin')->user()->hasPermission('settings-read')): ?>
                        <li>
                            <a href="<?php echo e(route('settings.index')); ?>" class="waves-effect">
                                <i class="fas fa-cog"></i><span><?php echo e(__('admin.settings')); ?></span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if(Auth::guard('admin')->user()->hasPermission('counters-read')): ?>
                        <li>
                            <a href="<?php echo e(route('counters.index')); ?>" class="waves-effect">
                                <i class="fas fa-cog"></i><span><?php echo e(__('admin.counters')); ?></span>
                            </a>
                        </li>
                        <?php endif; ?>
                        <?php if(Auth::guard('admin')->user()->hasPermission('locations-read')): ?>
                        <li>
                            <a href="<?php echo e(route('locations.index')); ?>" class="waves-effect">
                                <i class="fas fa-cog"></i><span><?php echo e(__('admin.locations')); ?></span>
                            </a>
                        </li>
                        <?php endif; ?>
                        
                        <?php if(Auth::guard('admin')->user()->hasPermission('covers-read')): ?>
                        <li>
                            <a href="<?php echo e(route('covers.index')); ?>" class="waves-effect">
                                <i class="fas fa-cog"></i><span><?php echo e(__('admin.covers')); ?></span>
                            </a>
                        </li>
                        <?php endif; ?>
                    </ul>

                </div>
                <!-- Sidebar -->
                

            </div>
            <!-- Sidebar -left -->

        </div>
        <!-- Left Sidebar End -->
<?php /**PATH C:\Users\dell\Desktop\zirikyashi\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>