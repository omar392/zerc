<?php $__env->startSection('content'); ?>
    <div class="content">
        <div class="container-fluid">
            <div class="page-title-box">
                <div class="row align-items-center">
                    <div class="col-sm-6">
                        <h4 class="page-title"><?php echo e(__('admin.settings')); ?></h4>
                    </div>
                    <div class="col-sm-6">
                        <ol class="breadcrumb float-right">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('adminhome')); ?>"><?php echo e(__('admin.home')); ?></a></li>
                            <li class="breadcrumb-item active"><?php echo e(__('admin.settings')); ?></li>
                        </ol>
                    </div>
                </div> <!-- end row -->
                <div class="row">
                    <div class="col-12">
                        <div class="card m-b-30">
                            <div class="card-body">
                                <form action="" id="settings" method="POST" data-parsley-validate>
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('put'); ?>
                                    <input type="hidden" name="settingId" id="setting_id" value="<?php echo e($setting->id); ?>"
                                        class="form-control">
                                    <div class="form-group row">
                                        <label for="example-text-input"
                                            class="col-sm-2 col-form-label"><?php echo e(__('admin.name_ar')); ?></label>
                                        <div class="col-sm-10">
                                            <input class="form-control" value="<?php echo e($setting->name_ar); ?>" type="text"
                                                name="name_ar" id="example-text-input"
                                                placeholder="<?php echo e(__('admin.name_ar')); ?> " required parsley-trigger="change">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-text-input"
                                            class="col-sm-2 col-form-label"><?php echo e(__('admin.name_en')); ?></label>
                                        <div class="col-sm-10">
                                            <input class="form-control" value="<?php echo e($setting->name_en); ?>" name="name_en"
                                                id="example-text-input" placeholder="<?php echo e(__('admin.name_en')); ?>" required
                                                parsley-trigger="change">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-text-input"
                                            class="col-sm-2 col-form-label"><?php echo e(__('admin.phone')); ?></label>
                                        <div class="col-sm-10">
                                            <input class="form-control" value="<?php echo e($setting->phone); ?>" name="phone"
                                                id="example-text-input" placeholder="<?php echo e(__('admin.phone')); ?>" required
                                                parsley-trigger="change">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-text-input" class="col-sm-2 col-form-label">Whatsapp</label>
                                        <div class="col-sm-10">
                                            <input class="form-control" value="<?php echo e($setting->whatsapp); ?>" name="whatsapp"
                                                id="example-text-input" placeholder="Whatsapp" required
                                                parsley-trigger="change">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-text-input" class="col-sm-2 col-form-label">Contact mail</label>
                                        <div class="col-sm-10">
                                            <input class="form-control" value="<?php echo e($setting->contact_mail); ?>" name="contact_mail"
                                                id="example-text-input" placeholder="contact_mail" required
                                                parsley-trigger="change">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-text-input" class="col-sm-2 col-form-label">Job mail</label>
                                        <div class="col-sm-10">
                                            <input class="form-control" value="<?php echo e($setting->job_mail); ?>" name="job_mail"
                                                id="example-text-input" placeholder="job_mail" required
                                                parsley-trigger="change">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-text-input" class="col-sm-2 col-form-label">Sub mail</label>
                                        <div class="col-sm-10">
                                            <input class="form-control" value="<?php echo e($setting->sub_mail); ?>" name="sub_mail"
                                                id="example-text-input" placeholder="sub_mail" required
                                                parsley-trigger="change">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-text-input"
                                            class="col-sm-2 col-form-label"><?php echo e(__('admin.email')); ?></label>
                                        <div class="col-sm-10">
                                            <input class="form-control" value="<?php echo e($setting->email); ?>" name="email"
                                                id="example-text-input" placeholder="<?php echo e(__('admin.email')); ?>" required
                                                parsley-trigger="change">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-text-input"
                                            class="col-sm-2 col-form-label"><?php echo e(__('admin.facebook')); ?></label>
                                        <div class="col-sm-10">
                                            <input class="form-control" value="<?php echo e($setting->facebook); ?>" name="facebook"
                                                id="example-text-input" placeholder="<?php echo e(__('admin.facebook')); ?>" required
                                                parsley-trigger="change">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-text-input"
                                            class="col-sm-2 col-form-label"><?php echo e(__('admin.twitter')); ?></label>
                                        <div class="col-sm-10">
                                            <input class="form-control" value="<?php echo e($setting->twitter); ?>" name="twitter"
                                                id="example-text-input" placeholder="<?php echo e(__('admin.twitter')); ?>" required
                                                parsley-trigger="change">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-text-input"
                                            class="col-sm-2 col-form-label"><?php echo e(__('admin.linkedin')); ?></label>
                                        <div class="col-sm-10">
                                            <input class="form-control" value="<?php echo e($setting->linkedin); ?>" name="linkedin"
                                                id="example-text-input" placeholder="<?php echo e(__('admin.linkedin')); ?>" required
                                                parsley-trigger="change">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-text-input"
                                            class="col-sm-2 col-form-label"><?php echo e(__('admin.instagram')); ?></label>
                                        <div class="col-sm-10">
                                            <input class="form-control" value="<?php echo e($setting->instagram); ?>"
                                                name="instagram" id="example-text-input"
                                                placeholder="<?php echo e(__('admin.instagram')); ?>" required
                                                parsley-trigger="change">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-text-input"
                                            class="col-sm-2 col-form-label"><?php echo e(__('admin.title_ar')); ?></label>
                                        <div class="col-sm-10">
                                            <input class="form-control" value="<?php echo e($setting->title_ar); ?>" type="text"
                                                name="title_ar" id="example-text-input"
                                                placeholder="<?php echo e(__('admin.title_ar')); ?> " required
                                                parsley-trigger="change">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-text-input"
                                            class="col-sm-2 col-form-label"><?php echo e(__('admin.title_en')); ?></label>
                                        <div class="col-sm-10">
                                            <input class="form-control" value="<?php echo e($setting->title_en); ?>" name="title_en"
                                                id="example-text-input" placeholder="<?php echo e(__('admin.title_en')); ?>" required
                                                parsley-trigger="change">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-text-input"
                                            class="col-sm-2 col-form-label"><?php echo e(__('admin.footer_ar')); ?></label>
                                        <div class="col-sm-10">
                                            <input class="form-control" value="<?php echo e($setting->footer_ar); ?>" type="text"
                                                name="footer_ar" id="example-text-input"
                                                placeholder="<?php echo e(__('admin.footer_ar')); ?> " required
                                                parsley-trigger="change">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-text-input"
                                            class="col-sm-2 col-form-label"><?php echo e(__('admin.footer_en')); ?></label>
                                        <div class="col-sm-10">
                                            <input class="form-control" value="<?php echo e($setting->footer_en); ?>" name="footer_en"
                                                id="example-text-input" placeholder="<?php echo e(__('admin.footer_en')); ?>" required
                                                parsley-trigger="change">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-text-input"
                                            class="col-sm-2 col-form-label"><?php echo e(__('admin.brand_title_ar')); ?></label>
                                        <div class="col-sm-10">
                                            <input class="form-control" value="<?php echo e($setting->brandtitle_ar); ?>" type="text"
                                                name="brandtitle_ar" id="example-text-input"
                                                placeholder="<?php echo e(__('admin.brandtitle_ar')); ?> " required
                                                parsley-trigger="change">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-text-input"
                                            class="col-sm-2 col-form-label"><?php echo e(__('admin.brand_title_en ')); ?></label>
                                        <div class="col-sm-10">
                                            <input class="form-control" value="<?php echo e($setting->brandtitle_en); ?>" type="text"
                                                name="brandtitle_en" id="example-text-input"
                                                placeholder="<?php echo e(__('admin.brandtitle_en')); ?> " required
                                                parsley-trigger="change">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-text-input"
                                            class="col-sm-2 col-form-label"><?php echo e(__('admin.welcome_text_ar')); ?></label>
                                        <div class="col-sm-10">
                                            <input class="form-control" value="<?php echo e($setting->welcometext_ar); ?>" type="text"
                                                name="welcometext_ar" id="example-text-input"
                                                placeholder="<?php echo e(__('admin.welcometext_ar')); ?> " required
                                                parsley-trigger="change">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-text-input"
                                            class="col-sm-2 col-form-label"><?php echo e(__('admin.welcome_text_en')); ?></label>
                                        <div class="col-sm-10">
                                            <input class="form-control" value="<?php echo e($setting->welcometext_en); ?>" type="text"
                                                name="welcometext_en" id="example-text-input"
                                                placeholder="<?php echo e(__('admin.welcometext_en')); ?> " required
                                                parsley-trigger="change">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-text-input"
                                            class="col-sm-2 col-form-label"><?php echo e(__('admin.msg_text_ar')); ?></label>
                                        <div class="col-sm-10">
                                            <input class="form-control" value="<?php echo e($setting->msgtext_ar); ?>" type="text"
                                                name="msgtext_ar" id="example-text-input"
                                                placeholder="<?php echo e(__('admin.msgtext_ar')); ?> " required
                                                parsley-trigger="change">
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-text-input"
                                            class="col-sm-2 col-form-label"><?php echo e(__('admin.msg_text_en')); ?></label>
                                        <div class="col-sm-10">
                                            <input class="form-control" value="<?php echo e($setting->msgtext_en); ?>" type="text"
                                                name="msgtext_en" id="example-text-input"
                                                placeholder="<?php echo e(__('admin.msgtext_en')); ?> " required
                                                parsley-trigger="change">
                                        </div>
                                    </div>

                                    <div class="form-group row">
                                        <label for="example-text-input"
                                            class="col-sm-2 col-form-label"><?php echo e(__('admin.address_ar')); ?></label>
                                        <div class="col-sm-10">
                                            <textarea class="form-control" name="address_ar" id="" cols="10" rows="10"><?php echo $setting->address_ar; ?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-text-input"
                                            class="col-sm-2 col-form-label"><?php echo e(__('admin.address_en')); ?></label>
                                        <div class="col-sm-10">
                                            <textarea class="form-control" name="address_en" id="" cols="10" rows="10"><?php echo $setting->address_en; ?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-text-input"
                                            class="col-sm-2 col-form-label"><?php echo e(__('admin.description_ar')); ?></label>
                                        <div class="col-sm-10">
                                            <textarea class="form-control" name="description_ar" id="" cols="10" rows="10"><?php echo $setting->description_ar; ?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-text-input"
                                            class="col-sm-2 col-form-label"><?php echo e(__('admin.description_en')); ?></label>
                                        <div class="col-sm-10">
                                            <textarea class="form-control" name="description_en" id="" cols="10" rows="10"><?php echo $setting->description_en; ?></textarea>
                                        </div>
                                    </div>
                                    <div class="form-group row">
                                        <label for="example-text-input"
                                            class="col-sm-2 col-form-label"><?php echo e(__('admin.image')); ?></label>
                                        <div class="col-sm-10">
                                            <input type="file" name="image" id="image"
                                                value="<?php echo e($setting->image); ?>" class="filestyle image"
                                                data-buttonname="btn-primary">
                                            <img src="<?php echo e(asset('dashboard/' . $setting->image)); ?>" width="340"
                                                height="200" alt=""
                                                style="margin-right: 70px;border-radius: 15px;" class="image-show" />
                                        </div>
                                    </div>
                                                                    <div class="form-group row">
                                    <label for="example-text-input"
                                        class="col-sm-2 col-form-label">mail_transport</label>
                                    <div class="col-sm-10">
                                        <input class="form-control" value="<?php echo e($setting->mail_transport); ?>"
                                            name="mail_transport" id="example-text-input"
                                            placeholder="mail_transport" required parsley-trigger="change" >
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="example-text-input"
                                        class="col-sm-2 col-form-label">mail_host</label>
                                    <div class="col-sm-10">
                                        <input class="form-control" value="<?php echo e($setting->mail_host); ?>"
                                            name="mail_host" id="example-text-input"
                                            placeholder="mail_host" required parsley-trigger="change" >
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="example-text-input"
                                        class="col-sm-2 col-form-label">mail_port</label>
                                    <div class="col-sm-10">
                                        <input class="form-control" value="<?php echo e($setting->mail_port); ?>"
                                            name="mail_port" id="example-text-input"
                                            placeholder="mail_port" required parsley-trigger="change" >
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="example-text-input"
                                        class="col-sm-2 col-form-label">mail_username</label>
                                    <div class="col-sm-10">
                                        <input class="form-control" value="<?php echo e($setting->mail_username); ?>"
                                            name="mail_username" id="example-text-input"
                                            placeholder="mail_username" required parsley-trigger="change" >
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="example-text-input"
                                        class="col-sm-2 col-form-label">mail_password</label>
                                    <div class="col-sm-10">
                                        <input class="form-control" type="password" value="<?php echo e($setting->mail_password); ?>"
                                            name="mail_password" id="example-text-input"
                                            placeholder="mail_password" required parsley-trigger="change" >
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="example-text-input"
                                        class="col-sm-2 col-form-label">mail_encryption</label>
                                    <div class="col-sm-10">
                                        <input class="form-control" value="<?php echo e($setting->mail_encryption); ?>"
                                            name="mail_encryption" id="example-text-input"
                                            placeholder="mail_encryption" required parsley-trigger="change" >
                                    </div>
                                </div>
                                <div class="form-group row">
                                    <label for="example-text-input"
                                        class="col-sm-2 col-form-label">mail_from</label>
                                    <div class="col-sm-10">
                                        <input class="form-control" value="<?php echo e($setting->mail_from); ?>"
                                            name="mail_from" id="example-text-input"
                                            placeholder="mail_from" required parsley-trigger="change" >
                                    </div>
                                </div>
                                    <?php if(Auth::guard('admin')->user()->hasPermission('settings-update')): ?>
                                        <div class="form-group text-center m-t-20">
                                            <div class="col-12">
                                                <button class="btn btn-primary btn-block btn-lg" name="submit"
                                                    type="submit"><?php echo e(__('admin.edit')); ?></button>
                                            </div>
                                        </div>
                                    <?php endif; ?>
                                </form>
                            </div>
                        </div>
                    </div> <!-- end col -->
                    <a href="<?php echo e(url()->previous()); ?>">
                        <button class="btn btn-primary"><?php echo e(__('admin.return')); ?> <i class="fas fa-backward"></i></button>
                    </a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('js'); ?>
    <script>
        $(function() {
            $.ajaxSetup({
                headers: {
                    'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                }
            });

            $('body').on('submit', '#settings', function(e) {
                e.preventDefault();
                //  alert('no problem');
                let id = $('#setting_id').val();
                var url = '<?php echo e(route('settings.update', ':id')); ?>';
                url = url.replace(':id', id);
                $.ajax({
                    url: url,
                    method: "post",
                    data: new FormData(this),
                    dataType: 'json',
                    cache: false,
                    contentType: false,
                    processData: false,

                    success: function(response) {
                        // console.log(response);
                        if (response.status == 'success') {
                            toastr.options = {
                                "closeButton": true,
                                "progressBar": true,
                                "showDuration": 500,
                                // "rtl": isRtl
                            }
                            toastr['info']("<?php echo e(__('admin.updatedsuccess')); ?>");
                        }
                    },

                });
            });

        });
    </script>

    <script>
        // image preview

        $(".image").change(function() {

            if (this.files && this.files[0]) {
                var reader = new FileReader();

                reader.onload = function(e) {
                    $('.image-show').attr('src', e.target.result);
                }

                reader.readAsDataURL(this.files[0]);
            }
        });

        $(".image_owner").change(function() {

            if (this.files && this.files[0]) {
                var reader = new FileReader();

                reader.onload = function(e) {
                    $('.image_owner-show').attr('src', e.target.result);
                }

                reader.readAsDataURL(this.files[0]);
            }
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\dell\Desktop\zirikyashi\resources\views/admin/settings/edit.blade.php ENDPATH**/ ?>